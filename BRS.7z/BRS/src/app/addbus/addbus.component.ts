import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addbus',
  templateUrl: './addbus.component.html',
  styleUrls: ['./addbus.component.css']
})
export class AddbusComponent implements OnInit {

  constructor() { }

  bus:any={};
  
  ngOnInit() {
  }

  addBus(){
    console.log(this.bus);
  }

}
