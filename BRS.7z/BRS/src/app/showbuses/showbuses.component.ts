import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import { Bus } from '../app.bus';
import { BusService } from '../busservice.service';


@Component({
  selector: 'app-showbuses',
  templateUrl: './showbuses.component.html',
  styleUrls: ['./showbuses.component.css']
})

export class ShowbusesComponent implements OnInit{
  // ngOnInit(): void {
  //   throw new Error("Method not implemented.");
  // }
  ngOnInit(){}
    flag: boolean =true;

    busList: Bus[]=[

      { busId: 11, busName: 101, busClass: 'abc', busType:'sleeper',source:'Thane',destination:'Thane',startTime:'10',endTime:'20',noOfSeats:40,costPerSeat:500,deleteFlag:0},
      { busId: 12, busName: 102, busClass: 'abc', busType:'sleeper',source:'Thane',destination:'Thane',startTime:'10',endTime:'20',noOfSeats:40,costPerSeat:500,deleteFlag:0}

        

    ];

    constructor(private service: BusService){

    }
    
    // ngOnInit(){
    //     this.service.getAllBuses().subscribe((data : Bus[])=> this.busList= data);
    // }

    deleteBus(id: any):any{
        this.service.deleteBus(id).subscribe();
        location.reload();
    }
}